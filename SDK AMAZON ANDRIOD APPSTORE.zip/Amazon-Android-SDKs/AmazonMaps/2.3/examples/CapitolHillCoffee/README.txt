CapitolHillCoffee samples


Before compiling, you need to configure your project to use Maps.

To configure your project in Eclipse, after importing a sample, add the Maps project by choosing “File/Import/General/Existing Projects into Workspace”. If you use ant, configure your project at the command line. For information about configuring your project in Eclipse or at the command line, see https://developer.amazon.com/sdk/maps/building.html#Configuring.

You can use the Amazon Mobile App SDK Eclipse Plugin as an alternative to manual configuration. For information about the Eclipse plugin, see https://developer.amazon.com/sdk/fire/eclipse-plugin.html.
